package com.example.StockSim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockSimApplicationTests {

	@Test
	void contextLoads() {
	}

}
